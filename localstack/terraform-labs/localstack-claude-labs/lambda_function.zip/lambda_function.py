import json
import boto3
import uuid
from datetime import datetime

s3 = boto3.client('s3')
BUCKET_NAME = 'serverless-demo-bucket'

def lambda_handler(event, context):
    try:
        # Extract data from the event
        body = json.loads(event['body']) if 'body' in event else {}
        
        # Generate a unique ID and timestamp
        item_id = str(uuid.uuid4())
        timestamp = datetime.now().isoformat()
        
        # Add metadata to the item
        item_data = {
            'id': item_id,
            'timestamp': timestamp,
            'data': body
        }
        
        # Save the item to S3
        s3.put_object(
            Bucket=BUCKET_NAME,
            Key=f"items/{item_id}.json",
            Body=json.dumps(item_data),
            ContentType='application/json'
        )
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'message': 'Data stored successfully',
                'id': item_id,
                'timestamp': timestamp
            })
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json'
            },
            'body': json.dumps({
                'error': str(e)
            })
        }
